---
trigger: always_on
---

# Regla de Alcance Quirúrgico Estricto (Cero Regresiones)

1. **Modifica ÚNICAMENTE lo solicitado de forma explícita** en el prompt actual.
2. **Prohibido refactorizar, "mejorar", renombrar, mover o eliminar** funciones, estilos CSS, `id` del DOM, componentes o reglas de negocio que ya funcionan y no fueron mencionados en la orden.
3. **Prohibido tocar el esquema de Supabase** (no crear tablas ni cambiar nombres de columnas) salvo instrucción expresa.
4. **Prohibido usar `.innerHTML`** para reconstruir contenedores que ya tienen listeners activos en `app_full.js`.
5. **Plan antes de editar:** Antes de aplicar cambios, verifica qué archivos exactos tocarás. Al finalizar, entrega siempre un listado exacto de archivos y funciones modificadas confirmando que no se alteró nada fuera de alcance.
