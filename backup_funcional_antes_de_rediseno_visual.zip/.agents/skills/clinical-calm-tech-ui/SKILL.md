---
name: clinical-calm-tech-ui
description: Audita y mejora visualmente interfaces clínicas de emergencias (HTML/CSS) aplicando estética Calm-Tech tecnológica, ergonomía anti-fatiga, WCAG 2.1 AA, IEC 62366-1 y exclusividad de colores MINSA/ESI sin alterar lógica JavaScript ni IDs del DOM. Usar cuando se pida rediseñar, estilizar, mejorar contraste, pulir tarjetas, modo oscuro o usabilidad visual. No usar para cambiar reglas médicas, cálculos financieros o backend.
---

# Skill: Diseño Clínico Calm-Tech (Hospital-Grade UI)

## Objetivo
Transformar interfaces clínicas en cabinas de trabajo modernas, tecnológicas, limpias y libres de fatiga visual, manteniendo seguridad clínica y cero regresiones funcionales.

## Restricciones Inquebrantables
1. **Solo capa visual:** Edita exclusivamente archivos CSS (`redesign_cockpit.css`, `ui_feedback.css` o variables CSS). No elimines ni renombres `id`, `name`, `data-*` ni destruyas nodos con `.innerHTML`.
2. **Exclusividad del semáforo clínico (NTS N° 042-MINSA / ESI v5):** Reserva Rojo (`#DC2626`), Naranja (`#EA580C`), Ámbar (`#CA8A04`), Verde (`#16A34A`) y Azul (`#2563EB`) únicamente para prioridades y alertas críticas. Nunca uses rojo saturado en botones decorativos.
3. **Doble codificación obligatoria (WCAG 2.1 AA):** Nunca comuniques gravedad solo por color; exige siempre `color + etiqueta + nivel` y contraste mínimo 4.5:1 en texto normal y 3:1 en bordes/iconos.

## Sistema de Diseño Base
- **Tipografía:** `Plus Jakarta Sans` (UI) + `JetBrains Mono` con `font-variant-numeric: tabular-nums` en signos vitales, NEWS2, DNI, códigos CIE-10/CPMS/CUM y montos `S/`.
- **Modo Claro (Calm-Tech):** Fondo `#F4F7FA`, tarjetas `#FFFFFF` con borde `1px solid #E2E8F0` y radio `12px`, texto `#0F172A` / `#475569`, acento tecnológico `#0E7490` (hover `#155E75`).
- **Modo Oscuro (`[data-theme="dark"]`):** Prohibido usar `#000000` puro. Fondo `#0B1120`, superficies `#111827` y `#1E293B`, bordes `#334155`, texto `#F1F5F9` / `#94A3B8`, acento `#06B6D4`.
- **Anti-ruido espacial:**
  - Elimina cajas doblemente anidadas; usa divisores sutiles (`1px solid`) y espaciado respirable (`16px–24px`).
  - Inputs de alta legibilidad (`min-height: 40px–42px`), estados `:focus-visible` nítidos en cian.
  - Toasts compactos (`max-width: 320px`) sin tapar controles; modales contenidos (`max-width: 460px–540px`).

## Flujo de Ejecución Obligatorio
1. **Inspección previa:** Revisa el CSS actual y lista los 3–5 mayores problemas visuales (densidad excesiva, bordes redundantes, desalineación, contraste insuficiente en claro/oscuro o mal uso de colores).
2. **Plan de tokens:** Define los ajustes exactos en variables CSS antes de escribir reglas.
3. **Aplicación quirúrgica:** Aplica cambios únicamente en la hoja de estilos designada, verificando responsive en escritorio (`1440px+`), tablet (`768px–1100px`) y móvil (`< 768px`).
4. **Autoverificación visual:** Si tienes acceso al navegador integrado, inspecciona la vista en Modo Claro y Modo Oscuro para confirmar que no haya texto cortado, chips desbordados ni superposiciones antes de entregar.
