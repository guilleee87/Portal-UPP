@echo off
title Abrir Web Triaje Directa
cls
echo Abriendo la aplicacion web interactiva en tu navegador...
start "" "index.html"
exit
